# SPDX-License-Identifier: GPL-2.0-or-later
# Copyright (C) 2009-2016 Lukas Rusak (lrusak@libreelec.tv)

import xbmc

monitor = xbmc.Monitor()
monitor.waitForAbort()
